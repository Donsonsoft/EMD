https://github.com/Donsonsoft/EMD

---------------------------------------------------------
Who is this project intended for?
For example, to anyone who just saves their passwords in a text file. Whether you share a computer with another person or store passwords separately on external storage, it is always a good idea to keep them encrypted. Unencrypted passwords in electronic form are relatively easy to steal. By encrypting your sensitive data in text form, you prevent its misuse.
---------------------------------------------------------

---------------------------------------------------------
ADVANTAGES
- you don't need an internet connection for encryption or decryption - everything is done directly in your web browser
- the encryption program is open-source - you can study it, edit it (I don't recommend unprofessionally editing javascript) and freely share the modified one, but don't forget to sign "your work" so that people know that the program is modified
- the original text (so-called open text) is not stored anywhere after encryption (not even in the text field after reloading the page)
---------------------------------------------------------

---------------------------------------------------------
LIMITATIONS
- The only allowed characters are aáäbcèdďeéfghiíjklåľmnňoóôpqrŕsštťuúvwxyýzžAÁÄBCČDĎEÉFGHIÍJKLĹĽMNŇOÓÔPQRŔŠTTUÚVWXYÝZŽ0123456789+-*/^<=>,.;:?!_§$€#&@{}[]()~|%¦˚ 
- The program cannot work with non-printable characters (but it can convert spaces to underscores "_")
- If the open text has more lines (or paragraphs), they must be converted to a specific character (the default is ;) so that they can be recovered during decryption
---------------------------------------------------------

---------------------------------------------------------
WARNING!
I, the author, am not responsible for any loss of your data. You have voluntarily decided to use my program and it is up to you to remember the encryption key or not to lose your own alphabets.
Beware of changes in EMD cipher versions! If you encrypt the text in a lower version, e.g. 1.0 and try to decrypt it in version 2.2, you will not get the original text! The first number is important - it indicates the version of the encryption algorithm, the numbers after the dot mean corrections in the design or some functionality, or the addition of functionality. So text encrypted with version 2.0 can be decrypted with version 2.2.
---------------------------------------------------------

---------------------------------------------------------
THE USE

Encryption
0. Get the text you want to encrypt :-)
1. Paste (or type) your text into the appropriate text box
2. Come up with a secure encryption key (password) and enter it in the appropriate field
3. Load encryption profile to increase security if you want.
4. Click the "Encrypt" button

Decryption
0. Get the text you want to decrypt :-)
1. Paste your text into the appropriate text box
2. Remember your encryption key (password), which you enter in the appropriate field
3. If you used encryption profile while encrypting, load it now as well.
4. Click the "Decrypt" button

- various error messages may appear as well as functions to correct some errors (replacement of spaces or paragraph marks)
- you can view the key by clicking on the image of the eye
- it is possible to use encryption profile that will increase the security of encryption (more info below)
- you can copy unencrypted and encrypted text to the clipboard using the buttons to the right of the text fields
---------------------------------------------------------

---------------------------------------------------------
ZIP FILE CONTENTS
- readme_en.txt is this introductory text :-)
- cypher_emd.html is the encryption program itself that can be run via any web browser (even on mobile), you don't need anything else for encryption
---------------------------------------------------------

---------------------------------------------------------
ENCRYPTION PROFILE (optional)
In version 2.2, functionality was added to create your own encryption profile without effort. Just click, save and use.

Features of the encryption profile:
- contains 128 lines and 128 characters in each of them
- the following characters are used in random order (characters are not repeated in line):
aáäbcèdďeéfghiíjklåľmnňoóôpqrŕsštťuúvwxyýzžAÁÄBCČDĎEÉFGHIÍJKLĹĽMNŇOÓÔPQRŔŠTTUÚVWXYÝZŽ0123456789+-*/^<=>,.;:?!_§$€#&@{}[]()~|%¦˚

What is the point of using encryption profile?
If you use encryption profile, you will significantly increase the security of your data (if, of course, you don't leave them in plain view of a potential attacker).
If you use a weak key (e.g. your dog's name), an attacker can crack the password so-called brute force, but using an encryption profile you will make such an attack impossible for him (if he doesn't get his hands on the file)
By creating your own alphabets, you own a unique file, which is on the one hand impractical, since you have to carry it with you for decryption, but it is much safer.
It's actually a 16384-character unique password, which is why it's so secure.
---------------------------------------------------------